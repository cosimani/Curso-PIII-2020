
const unsigned BUFFFER_SIZE  = 32;
const unsigned FILTER_ORDER  = 30;

const unsigned Pasabajos_150_a_4000[ FILTER_ORDER + 1 ] = {
    0xFFD5, 0xFFEB, 0x000F, 0x005A, 0x00E6, 0x01C9,
    0x0312, 0x04C4, 0x06D3, 0x0926, 0x0B98, 0x0DF9,
    0x1017, 0x11C3, 0x12D5, 0x1333, 0x12D5, 0x11C3,
    0x1017, 0x0DF9, 0x0B98, 0x0926, 0x06D3, 0x04C4,
    0x0312, 0x01C9, 0x00E6, 0x005A, 0x000F, 0xFFEB,
    0xFFD5
};

const unsigned Pasaaltos_250_a_4000[FILTER_ORDER+1] = {
      0x0015, 0x002F, 0x0059, 0x0092, 0x00CB, 0x00E5,
      0x00B0, 0x0000, 0xFEB1, 0xFCB9, 0xFA34, 0xF75D,
      0xF48E, 0xF22B, 0xF091, 0x7000, 0xF091, 0xF22B,
      0xF48E, 0xF75D, 0xFA34, 0xFCB9, 0xFEB1, 0x0000,
      0x00B0, 0x00E5, 0x00CB, 0x0092, 0x0059, 0x002F,
      0x0015};

// 0 - Original
// 1 - Filtro 1
// 2 - Filtro 2
int seleccion_filtro = 0;

unsigned inext;                       // Input buffer index
ydata unsigned input[ BUFFFER_SIZE ];   // Input buffer, must be in Y data space

#define FRECUENCIA_MUESTREO 4000
#define CLOCK_ns 400

void  detectarIntADC()  org 0x002a  {
    unsigned CurrentValue;

    IFS0bits.ADIF = 0;
    LATFbits.LATF1 = ~LATFbits.LATF1;
    
    if ( seleccion_filtro == 0 )  {
        LATBbits.LATB4  = ADCBUF0.B0;
        LATBbits.LATB5  = ADCBUF0.B1;
        LATBbits.LATB6  = ADCBUF0.B2;
        LATBbits.LATB7  = ADCBUF0.B3;
        LATBbits.LATB8  = ADCBUF0.B4;
        LATBbits.LATB9  = ADCBUF0.B5;
        LATBbits.LATB10 = ADCBUF0.B6;
        LATBbits.LATB11 = ADCBUF0.B7;
        LATBbits.LATB12 = ADCBUF0.B8;
        LATCbits.LATC13 = ADCBUF0.B9;
        LATDbits.LATD0  = ADCBUF0.B10;
        LATDbits.LATD1  = ADCBUF0.B11;
        
        return;
    }
    
    input[ inext ] = ADCBUF0 - 1638;  // Fetch sample

    if( seleccion_filtro == 1 )  {
        CurrentValue = FIR_Radix( FILTER_ORDER + 1,  // Filter order
                                  Pasabajos_150_a_4000,  // b coefficients of the filter
                                  BUFFFER_SIZE,      // Input buffer length
                                  input,             // Input buffer
                                  inext );           // Current sample
                                  
    }
    else if( seleccion_filtro == 2 )  {
        CurrentValue = FIR_Radix( FILTER_ORDER + 1,  // Filter order
                                  Pasaaltos_250_a_4000,  // b coefficients of the filter
                                  BUFFFER_SIZE,      // Input buffer length
                                  input,             // Input buffer
                                  inext );           // Current sample
    }

    inext = ( inext + 1 ) & ( BUFFFER_SIZE - 1 );  // inext = ( inext + 1 ) mod BUFFFER_SIZE;
    
    CurrentValue = CurrentValue + 1638;
    
    LATBbits.LATB4 =  ( ( unsigned int )CurrentValue & 0b0000000000000001) >> 0;
    LATBbits.LATB5 =  ( ( unsigned int )CurrentValue & 0b0000000000000010) >> 1;
    LATBbits.LATB6 =  ( ( unsigned int )CurrentValue & 0b0000000000000100) >> 2;
    LATBbits.LATB7 =  ( ( unsigned int )CurrentValue & 0b0000000000001000) >> 3;
    LATBbits.LATB8 =  ( ( unsigned int )CurrentValue & 0b0000000000010000) >> 4;
    LATBbits.LATB9 =  ( ( unsigned int )CurrentValue & 0b0000000000100000) >> 5;
    LATBbits.LATB10 = ( ( unsigned int )CurrentValue & 0b0000000001000000) >> 6;
    LATBbits.LATB11 = ( ( unsigned int )CurrentValue & 0b0000000010000000) >> 7;
    LATBbits.LATB12 = ( ( unsigned int )CurrentValue & 0b0000000100000000) >> 8;
    LATCbits.LATC13 = ( ( unsigned int )CurrentValue & 0b0000001000000000) >> 9;
    LATDbits.LATD0 =  ( ( unsigned int )CurrentValue & 0b0000010000000000) >> 10;
    LATDbits.LATD1 =  ( ( unsigned int )CurrentValue & 0b0000100000000000) >> 11;
}

void detectarIntT2() org 0x0020  {
    IFS0bits.T2IF = 0;  //borra bandera de interrupcion de T2

    LATFbits.LATF0 = ~LATFbits.LATF0;

    ADCON1bits.SAMP = 1; // pedimos muestras
    asm nop;  // ciclo instruccion sin operacion
    ADCON1bits.SAMP = 0;  // etener muestra e inicia conversion
}

void detectarINT0() org 0x0014  {
    IFS0bits.INT0IF = 0;
    seleccion_filtro = seleccion_filtro + 1;
    
    if ( seleccion_filtro >= 3 )
        seleccion_filtro = 0;
}

void configINT0()  {
    IEC0bits.INT0IE = 1;
}

void configADC()  {
    ADPCFG = 0b111011;  // AN2
    ADCHS = 2; // AN2
    ADCON1bits.SSRC = 0b000; // muestreo manual
    ADCON2bits.VCFG = 0b000;  // AVdd y AVss
    IEC0bits.ADIE = 1;  // habilitamos interrupcion del ADC
}

void configT2()  {
    PR2 = ( 1000 * 1000 * 1000 ) / ( FRECUENCIA_MUESTREO * CLOCK_ns );
    IEC0bits.T2IE = 1;
}

void configPuertos()  {

    // RB0 - AN0 - VRef+
    // RB1 - AN1 - VRef-

    TRISBbits.TRISB2 = 1;  // AN2 - senal

    // RB3 - AN3
    
    // RA11 - INT0

    TRISBbits.TRISB4  = 0;  // Bit 0
    TRISBbits.TRISB5  = 0;  // Bit 1
    TRISBbits.TRISB6  = 0;  // Bit 2
    TRISBbits.TRISB7  = 0;  // Bit 3
    TRISBbits.TRISB8  = 0;  // Bit 4
    TRISBbits.TRISB9  = 0;  // Bit 5
    TRISBbits.TRISB10 = 0;  // Bit 6
    TRISBbits.TRISB11 = 0;  // Bit 7
    TRISBbits.TRISB12 = 0;  // Bit 8
    TRISCbits.TRISC13 = 0;  // Bit 9
    TRISDbits.TRISD0  = 0;  // Bit 10
    TRISDbits.TRISD1  = 0;  // Bit 11

    TRISFbits.TRISF0  = 0;  // Debug T2
    TRISFbits.TRISF1  = 0;  // Debug ADC
}

void main()  {
    configPuertos();
    configINT0();
    configT2();
    configADC();

    ADCON1bits.ADON = 1;

    T2CONbits.TON = 1;

    while( 1 )  {  }
}
