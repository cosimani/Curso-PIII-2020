// dsPIC33FJ32MC202

// Senal de entrada:
//      40 Hz / offset 1 V / Vpp 1 V

// ADC
//      10 bits / AN4 / VRef+ y VRef- / Muestreado con Timer 2 a 1kHz

#define FRECUENCIA_MUESTREO 1000

void configuracionPuertos()  {

    TRISBbits.TRISB2 = 1;  // Entrada AN4

    TRISBbits.TRISB9 = 0;  // Mas significativo
    TRISBbits.TRISB8 = 0;
    TRISBbits.TRISB11 = 0;
    TRISBbits.TRISB6 = 0;
    TRISBbits.TRISB5 = 0;
    TRISBbits.TRISB4 = 0;
    TRISBbits.TRISB3 = 0;
    TRISBbits.TRISB10 = 0;
    TRISBbits.TRISB1 = 0;
    TRISBbits.TRISB0 = 0;  // Menos significativo
    
    TRISBbits.TRISB7 = 1;  // Pulsador para incrementar la frecuencia
    TRISBbits.TRISB12 = 1;  // Pulsador para procesar o no

    TRISBbits.TRISB14 = 0;  // debug_timer
    TRISBbits.TRISB15 = 0;  // debug_adc
}

void configuracionT2()  {
    PR2 = 1 / ( ( FRECUENCIA_MUESTREO / 1000 ) * 0.0002f );
    IEC0bits.T2IE = 1;
}

void config_adc()  {
    ADPCFG = 0b1111111111101111; // AN4 como entrada analogica
    AD1CHS0 = 4;  // Muestreo la entrada analogica AN4

    AD1CON1bits.AD12B = 0;  // ADC de 10 bits
    AD1CON1bits.FORM = 0b00;  // Formato de salida entero

    AD1CON2bits.VCFG = 0b011;  // Referencia con VRef+ y VRef-

    IEC0bits.AD1IE = 1;
}

void detectarInt_T2() org 0x0022  {
    IFS0bits.T2IF = 0;

    LATBbits.LATB14 = ~LATBbits.LATB14;  // debug_timer

    AD1CON1bits.DONE = 0;  // Antes de pedir una muestra ponemos en cero
    AD1CON1bits.SAMP = 1;  // Pedimos una muestra

    asm nop;  // Tiempo que debemos esperar para que tome una muestra

    AD1CON1bits.SAMP = 0;  // Pedimos que retenga la muestra
}

void detect_adc() org 0x002e  {
    int muestra_adc;

    IFS0bits.AD1IF = 0;

    LATBbits.LATB15 = ~LATBbits.LATB15;  // debug_adc
    
    muestra_adc = ADCBUF0;
    
    if ( PORTBbits.RB12 == 1 && muestra_adc > 511 )
        muestra_adc = 211;

    LATBbits.LATB9 = ( muestra_adc & 0b0000001000000000 ) >> 9;
    LATBbits.LATB8 = ( muestra_adc & 0b0000000100000000 ) >> 8;
    LATBbits.LATB11 =( muestra_adc & 0b0000000010000000 ) >> 7;
    LATBbits.LATB6 = ( muestra_adc & 0b0000000001000000 ) >> 6;
    LATBbits.LATB5 = ( muestra_adc & 0b0000000000100000 ) >> 5;
    LATBbits.LATB4 = ( muestra_adc & 0b0000000000010000 ) >> 4;
    LATBbits.LATB3 = ( muestra_adc & 0b0000000000001000 ) >> 3;
    LATBbits.LATB10 =( muestra_adc & 0b0000000000000100 ) >> 2;
    LATBbits.LATB1 = ( muestra_adc & 0b0000000000000010 ) >> 1;
    LATBbits.LATB0 = ( muestra_adc & 0b0000000000000001 ) >> 0;
}

void main()  {
    configuracionPuertos();
    configuracionT2();
    config_adc();

    AD1CON1bits.ADON = 1;
    T2CONbits.TON = 1;

    while( 1 )  {  }
}